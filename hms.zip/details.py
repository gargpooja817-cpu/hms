from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import random
import mysql.connector


class DetailsRoom:
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Management")
        self.root.geometry("1295x550+230+220")

        # ================= TITLE ==================
        lbl_title = Label(self.root, text="ROOM BOOKING DETAILS",
                          font=("arial", 18, "bold"),
                          bg="black", fg="gold", bd=4, relief=RIDGE)
        lbl_title.place(x=0, y=0, width=1295, height=50)

        # ================= LOGO IMAGE ==================
        img2 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel3.jpg")
        img2 = img2.resize((100, 40), Image.LANCZOS)
        self.photoimg2 = ImageTk.PhotoImage(img2)

        lbling = Label(self.root, image=self.photoimg2, bd=0, relief=RIDGE)
        lbling.place(x=5, y=2, width=100, height=40)

        # ================= LEFT LABEL FRAME ==================
        self.labelframeleft = LabelFrame(self.root, bd=2, relief=RIDGE,
                                         text="New Room Add",
                                         font=("arial", 12, "bold"), padx=2)
        self.labelframeleft.place(x=2, y=50, width=425, height=490)

        # ================= Floor ==================
        Label(self.labelframeleft, text="Floor:",
              font=("arial", 12, "bold")).grid(row=0, column=0, padx=10, pady=5, sticky=W)
        self.var_floor = StringVar()

        entry_floor = ttk.Entry(self.labelframeleft, textvariable=self.var_floor,
                                width=16, font=("arial", 13))
        entry_floor.grid(row=0, column=1, padx=10, pady=5, sticky=W)

        # ================= Room Number ==================
        Label(self.labelframeleft, text="Room Number:",
              font=("arial", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky=W)
        self.var_roomnumber = StringVar()

        entry_RoomNumber = ttk.Entry(self.labelframeleft, textvariable=self.var_roomnumber,
                                     width=16, font=("arial", 13))
        entry_RoomNumber.grid(row=1, column=1, padx=10, pady=5, sticky=W)

        # ================= Room Type ==================
        Label(self.labelframeleft, text="Room Type:",
              font=("arial", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky=W)
        self.var_roomtype = StringVar()

        entry_RoomType = ttk.Entry(self.labelframeleft, textvariable=self.var_roomtype,
                                   width=16, font=("arial", 13))
        entry_RoomType.grid(row=2, column=1, padx=10, pady=5, sticky=W)

        # ========== BUTTON FRAME ==========
        btn_frame = Frame(self.labelframeleft, bd=2, relief=RIDGE)
        btn_frame.place(x=0, y=200, width=520, height=40)

        Button(btn_frame, text="Add", command=self.add_data, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=0)

        Button(btn_frame, text="Update",command=self.update, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=1)

        Button(btn_frame, text="Delete",command=self.mDelete, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=2)

        Button(btn_frame, text="Reset",command=self.reset, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=3)

        # ================= TABLE FRAME =================
        Table_Frame = LabelFrame(self.root, bd=2, relief=RIDGE,
                                 text="Show Room Details",
                                 font=("arial", 12, "bold"))
        Table_Frame.place(x=600, y=55, width=600, height=350)

        scroll_x = ttk.Scrollbar(Table_Frame, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(Table_Frame, orient=VERTICAL)

        self.room_Table = ttk.Treeview(
            Table_Frame,
            columns=("floor", "roomno", "roomtype"),
            xscrollcommand=scroll_x.set,
            yscrollcommand=scroll_y.set
        )

        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.room_Table.xview)
        scroll_y.config(command=self.room_Table.yview)

        self.room_Table.heading("floor", text="Floor")
        self.room_Table.heading("roomno", text="Room Number")
        self.room_Table.heading("roomtype", text="Room Type")

        for col in ("floor", "roomno", "roomtype"):
            self.room_Table.column(col, width=100)

        self.room_Table["show"] = "headings"
        self.room_Table.pack(fill=BOTH, expand=1)

        self.room_Table.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()

    # =============== ADD DATA =================
    def add_data(self):
        if self.var_floor.get() == "" or self.var_roomtype.get() == "":
            messagebox.showerror("Error", "All fields are required", parent=self.root)
        else:
            try:
           

                conn = mysql.connector.connect(
                    host="localhost",
                    username="root",
                    password="Poojagarg@111",
                    database="hotel"
                )
                mycursor = conn.cursor()

                mycursor.execute(
                    "INSERT INTO details (Floor,RoomNo,RoomType) VALUES (%s,%s,%s)",
                    (
                        self.var_floor.get(),
                        self.var_roomnumber.get(),
                        self.var_roomtype.get(),
                    )
                )

                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success", "New Room Added Sucessfully", parent=self.root)

            except Exception as e:
                messagebox.showerror("Error", f"Error: {str(e)}", parent=self.root)

    # =============== FETCH DATA =================
    def fetch_data(self):
        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM details")
            rows = cursor.fetchall()

            self.room_Table.delete(*self.room_Table.get_children())

            for row in rows:
                self.room_Table.insert("", END, values=row)

            conn.close()

        except Exception as e:
            messagebox.showerror("Error", f"Error: {str(e)}", parent=self.root)


    # ================= GET CURSOR =================
    def get_cursor(self, event=""):
        cursor_row = self.room_Table.focus()
        content = self.room_Table.item(cursor_row)
        row = content["values"]

        if row:
            self.var_floor.set(row[0])
            self.var_roomnumber.set(row[1])
            self.var_roomtype.set(row[2])    

        # ================= UPDATE =================
    def update(self):
        if self.var_floor.get() == "":
            messagebox.showerror("Error", "Please enter floor number", parent=self.root)
        else:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111",
                database="hotel"
            )
            my_cursor = conn.cursor()

            my_cursor.execute(
                "UPDATE details SET Floor=%s, RoomNo=%s, RoomType=%s WHERE RoomNo=%s",
                (
                    self.var_floor.get(),
                    self.var_roomnumber.get(),
                    self.var_roomtype.get(),
                    
                )
            )


            conn.commit()
            conn.close()
            self.fetch_data()
            messagebox.showinfo("Update", "New Room details updated successfully", parent=self.root)


    # ================= DELETE =================
    def mDelete(self):
        mDelete = messagebox.askyesno("Hotel Management System",
                                      "Do you want to delete this room?",
                                      parent=self.root)
        if mDelete:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111",
                database="hotel"
            )
            my_cursor = conn.cursor()
            query = "DELETE FROM details WHERE RoomNo=%s"
            value = (self.var_roomnumber.get(),)
            my_cursor.execute(query, value)
            conn.commit()
            conn.close()
            self.fetch_data()        

    # ================= RESET =================
    def reset(self):
        x = random.randint(1000, 9999)
        self.var_floor.set(str(x))
        self.var_roomnumber.set("")
        self.var_roomtype.set("")
      





# ================= MAIN LOOP ==================
if __name__ == "__main__":
    root = Tk()
    app = DetailsRoom(root)
    root.mainloop()
