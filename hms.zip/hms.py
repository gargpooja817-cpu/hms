from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import mysql.connector
from hotel import HotelManagementSystem





def main():
    win = Tk()
    app = login_window(win)
    win.mainloop()


class login_window:
    def __init__(self, root):
        self.root = root
        self.root.title("Login")
        self.root.geometry("1550x800+0+0")

        # Background image
        bg_img = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel10.jpg")
        bg_img = bg_img.resize((1550, 800), Image.LANCZOS)
        self.bg_ImageTk = ImageTk.PhotoImage(bg_img)
        lbl_bg = Label(self.root, image=self.bg_ImageTk)
        lbl_bg.place(x=0, y=0, relwidth=1, relheight=1)

        # Login frame
        frame = Frame(self.root, bg="black")
        frame.place(x=610, y=170, width=340, height=450)

        # Icon
        Img = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel11.jpg")
        Img = Img.resize((100, 100), Image.LANCZOS)
        self.PhotoImg = ImageTk.PhotoImage(Img)
        Label(frame, image=self.PhotoImg, bg="black").place(x=120, y=5, width=100, height=100)

        Label(frame, text="Get Started", font=("times new roman", 20, "bold"), fg="white", bg="black")\
            .place(x=95, y=110)

        # Username
        Label(frame, text="Username", font=("times new roman", 15, "bold"),
              fg="white", bg="black").place(x=70, y=155)
        self.txtuser = ttk.Entry(frame, font=("times new roman", 15, "bold"))
        self.txtuser.place(x=40, y=180, width=270)

        # Password
        Label(frame, text="Password", font=("times new roman", 15, "bold"),
              fg="white", bg="black").place(x=70, y=225)
        self.txtpass = ttk.Entry(frame, font=("times new roman", 15, "bold"), show="*")
        self.txtpass.place(x=40, y=250, width=270)

        # Username icon
        img2 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel11.jpg")
        img2 = img2.resize((25, 25), Image.LANCZOS)
        self.photoImage2 = ImageTk.PhotoImage(img2)
        Label(frame, image=self.photoImage2, bg="black").place(x=40, y=155, width=25, height=25)

        # Password icon
        img3 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel12.jpg")
        img3 = img3.resize((25, 25), Image.LANCZOS)
        self.photoImage3 = ImageTk.PhotoImage(img3)
        Label(frame, image=self.photoImage3, bg="black").place(x=40, y=225, width=25, height=25)

        # Login button
        Button(frame, command=self.login, text="Login",
               font=("times new roman", 15, "bold"), bd=3,
               relief=RIDGE, fg="white", bg="red").place(x=110, y=300, width=120, height=35)

        # Register button
        Button(frame, text="New User Register", command=self.register_window,
               font=("times new roman", 10, "bold"),
               borderwidth=0, fg="white", bg="black").place(x=10, y=350, width=160)

        # Forgot Password button
        Button(frame, text="Forgot Password", command=self.forgot_password_window,
               font=("times new roman", 10, "bold"),
               borderwidth=0, fg="white", bg="black").place(x=10, y=380, width=160)

    # ---------------- LOGIN FUNCTION ----------------
    def login(self):
        if self.txtuser.get() == "" or self.txtpass.get() == "":
            messagebox.showerror("Error", "All fields are required")
            return

        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM register WHERE email=%s AND password=%s",
                           (self.txtuser.get(), self.txtpass.get()))
            row = cursor.fetchone()

            if row is None:
                messagebox.showerror("Error", "Invalid Username or Password")
            else:
                open_main=messagebox.askyesno("YesNo","Access only admin!")
            if open_main>0:
                self.new_window=Toplevel(self.root)
                self.app=HotelManagementSystem(self.new_window)

            conn.close()

        except Exception as es:
            messagebox.showerror("Error", f"Due To: {str(es)}")

    # ---------------- OPEN REGISTER WINDOW ----------------
    def register_window(self):
        self.new_window = Toplevel(self.root)
        self.app = Register(self.new_window)




    # ---------------- FORGOT PASSWORD WINDOW ----------------
    def forgot_password_window(self):
        if self.txtuser.get() == "":
            messagebox.showerror("Error", "Please enter Email to reset password")
            return

        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM register WHERE email=%s", (self.txtuser.get(),))
            row = cursor.fetchone()

            if row is None:
                messagebox.showerror("Error", "Invalid Email")
            else:
                self.reset_password_window()


            conn.close()

        except Exception as es:
            messagebox.showerror("Error", f"Due To: {str(es)}")

    # ---------------- RESET PASSWORD POPUP ----------------
    def reset_password_window(self):
        self.root2 = Toplevel()
        self.root2.title("Forgot Password")
        self.root2.geometry("340x450+610+170")
        self.root2.config(bg="white")

        Label(self.root2, text="Forget Password",
              font=("times new roman", 20, "bold"),
              fg="red", bg="white").place(x=0, y=10, relwidth=1)

        Label(self.root2, text="Select Security Question",
              font=("times new roman", 15, "bold"),
              bg="white").place(x=50, y=80)

        self.combo_security_Q = ttk.Combobox(
            self.root2, font=("times new roman", 15, "bold"), state="readonly")
        self.combo_security_Q["values"] = (
            "Select", "Your Birth Place", "Your Girlfriend Name", "Your Pet Name")
        self.combo_security_Q.current(0)
        self.combo_security_Q.place(x=50, y=115, width=240)

        Label(self.root2, text="Security Answer",
              font=("times new roman", 15, "bold"),
              bg="white").place(x=50, y=165)

        self.txt_securityA = ttk.Entry(self.root2, font=("times new roman", 15))
        self.txt_securityA.place(x=50, y=195, width=240)

        Label(self.root2, text="New Password",
              font=("times new roman", 15, "bold"),
              bg="white").place(x=50, y=240)

        self.txt_newpass = ttk.Entry(self.root2, font=("times new roman", 15), show="*")
        self.txt_newpass.place(x=50, y=270, width=240)

        Button(self.root2, text="Reset", fg="white", bg="green",
               font=("times new roman", 15, "bold"),
               command=self.reset_pass).place(x=120, y=330, width=100, height=35)

    # ---------------- RESET PASSWORD FUNCTION ----------------
    def reset_pass(self):
        if self.combo_security_Q.get() == "Select":
            messagebox.showerror("Error", "Select Security Question")
            return

        if self.txt_securityA.get() == "":
            messagebox.showerror("Error", "Enter Security Answer")
            return

        if self.txt_newpass.get() == "":
            messagebox.showerror("Error", "Enter New Password")
            return

        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            cursor = conn.cursor()

            cursor.execute(
                "SELECT * FROM register WHERE email=%s AND securityQ=%s AND securityA=%s",
                (
                    self.txtuser.get(),
                    self.combo_security_Q.get(),
                    self.txt_securityA.get()
                )
            )
            row = cursor.fetchone()

            if row is None:
                messagebox.showerror("Error", "Security Question or Answer is Incorrect")
            else:
                cursor.execute(
                    "UPDATE register SET password=%s WHERE email=%s",
                    (self.txt_newpass.get(), self.txtuser.get())
                )
                conn.commit()
                messagebox.showinfo("Success", "Password Reset Successfully", parent=self.root2)
                self.root2.destroy()

            conn.close()

        except Exception as es:
            messagebox.showerror("Error", f"Due To: {str(es)}")


# ---------------- REGISTER CLASS ----------------
class Register:
    def __init__(self, root):
        self.root = root
        self.root.title("Register")
        self.root.geometry("1600x900+0+0")

        # Variables
        self.var_fname = StringVar()
        self.var_lname = StringVar()
        self.var_contact = StringVar()
        self.var_email = StringVar()
        self.var_securityQ = StringVar()
        self.var_securityA = StringVar()
        self.var_pass = StringVar()
        self.var_confpass = StringVar()

        # Background
        bg_img = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel13.jpg")
        bg_img = bg_img.resize((1600, 900))
        self.bg = ImageTk.PhotoImage(bg_img)
        Label(self.root, image=self.bg).place(x=0, y=0, relwidth=1, relheight=1)

        # Left image
        left_img = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel14.jpg")
        left_img = left_img.resize((470, 550))
        self.bg1 = ImageTk.PhotoImage(left_img)
        Label(self.root, image=self.bg1).place(x=50, y=100, width=470, height=550)

        # Form frame
        frame = Frame(self.root, bg="white")
        frame.place(x=520, y=100, width=800, height=550)

        Label(frame, text="REGISTER HERE",
              font=("times new roman", 25, "bold"),
              fg="darkgreen", bg="white").place(x=20, y=20)

        # Row 1
        Label(frame, text="First Name", font=("times new roman", 15, "bold"), bg="white").place(x=50, y=100)
        ttk.Entry(frame, textvariable=self.var_fname, font=("times new roman", 15)).place(x=50, y=130, width=250)

        Label(frame, text="Last Name", font=("times new roman", 15, "bold"), bg="white").place(x=370, y=100)
        ttk.Entry(frame, textvariable=self.var_lname, font=("times new roman", 15)).place(x=370, y=130, width=250)

        # Row 2
        Label(frame, text="Contact No", font=("times new roman", 15, "bold"), bg="white").place(x=50, y=170)
        ttk.Entry(frame, textvariable=self.var_contact, font=("times new roman", 15)).place(x=50, y=200, width=250)

        Label(frame, text="Email", font=("times new roman", 15, "bold"), bg="white").place(x=370, y=170)
        ttk.Entry(frame, textvariable=self.var_email, font=("times new roman", 15)).place(x=370, y=200, width=250)

        # Row 3
        Label(frame, text="Select Security Question", font=("times new roman", 15, "bold"), bg="white").place(x=50, y=240)
        self.combo_security_Q = ttk.Combobox(frame, textvariable=self.var_securityQ,
                                             font=("times new roman", 15, "bold"), state="readonly")
        self.combo_security_Q["values"] = ("Select", "Your Birth Place", "Your Girlfriend Name", "Your Pet Name")
        self.combo_security_Q.current(0)
        self.combo_security_Q.place(x=50, y=270, width=250)

        Label(frame, text="Security Answer", font=("times new roman", 15, "bold"), bg="white").place(x=370, y=240)
        ttk.Entry(frame, textvariable=self.var_securityA, font=("times new roman", 15)).place(x=370, y=270, width=250)

        # Row 4
        Label(frame, text="Password", font=("times new roman", 15, "bold"), bg="white").place(x=50, y=310)
        ttk.Entry(frame, textvariable=self.var_pass, font=("times new roman", 15), show="*").place(x=50, y=340, width=250)

        Label(frame, text="Confirm Password", font=("times new roman", 15, "bold"), bg="white").place(x=370, y=310)
        ttk.Entry(frame, textvariable=self.var_confpass, font=("times new roman", 15), show="*").place(x=370, y=340, width=250)

        # Terms & conditions
        self.var_chk = IntVar()
        Checkbutton(frame, text="I Agree The Terms & Conditions", variable=self.var_chk,
                    font=("times new roman", 12, "bold"), bg="white").place(x=50, y=380)

        # Register button
        reg_img = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\register.jpg")
        reg_img = reg_img.resize((200, 40))
        self.photoimage = ImageTk.PhotoImage(reg_img)
        Button(frame, image=self.photoimage, command=self.register_data, borderwidth=0).place(x=16, y=420, width=200)

        # Login button
        login_img = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\login.jpg")
        login_img = login_img.resize((200, 40))
        self.photoimage1 = ImageTk.PhotoImage(login_img)
        Button(frame, image=self.photoimage1, command=self.login_data, borderwidth=0).place(x=330, y=420, width=200)

    # SAVE REGISTER DATA
    def register_data(self):
        if self.var_fname.get() == "" or self.var_email.get() == "" or self.var_securityQ.get() == "Select":
            messagebox.showerror("ERROR", "All fields are required")
        elif self.var_pass.get() != self.var_confpass.get():
            messagebox.showerror("ERROR", "Passwords do not match")
        elif self.var_chk.get() == 0:
            messagebox.showerror("ERROR", "Please accept Terms & Conditions")
        else:
            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    username="root",
                    password="Poojagarg@111",
                    database="hotel"
                )
                cursor = conn.cursor()

                cursor.execute("SELECT * FROM register WHERE email=%s", (self.var_email.get(),))
                row = cursor.fetchone()

                if row is not None:
                    messagebox.showerror("Error", "User already exists")
                else:
                    cursor.execute(
                        "INSERT INTO register (fname, lname, contact, email, securityQ, securityA, password) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s)",
                        (
                            self.var_fname.get(),
                            self.var_lname.get(),
                            self.var_contact.get(),
                            self.var_email.get(),
                            self.var_securityQ.get(),
                            self.var_securityA.get(),
                            self.var_pass.get()
                        )
                    )
                    conn.commit()
                    messagebox.showinfo("Success", "Registration Successful")

                conn.close()

            except Exception as es:
                messagebox.showerror("Error", f"Due To: {str(es)}")

    def login_data(self):
        self.root.destroy()
    




from tkinter import *
from PIL import Image, ImageTk
from customer import cust_win
from roombooking import Roombooking
from details import DetailsRoom





class HotelManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("hotel management system")
        self.root.geometry("1550x800+0+0")

        # ===================== 1st image ======================
        img1 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel2.jpg")
        img1 = img1.resize((1550, 140), Image.LANCZOS)
        self.photoimg1 = ImageTk.PhotoImage(img1)

        lblimg = Label(self.root, image=self.photoimg1, bd=4, relief=RIDGE)
        lblimg.place(x=0, y=0, width=1550, height=140)

        # ===================== logo ======================
        img2 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel3.jpg")
        img2 = img2.resize((230, 140), Image.LANCZOS)
        self.photoimg2 = ImageTk.PhotoImage(img2)

        lblimg2 = Label(self.root, image=self.photoimg2, bd=4, relief=RIDGE)
        lblimg2.place(x=0, y=0, width=230, height=140)

        # ===================== title ======================
        lbl_title = Label(
            self.root, 
            text="HOTEL MANAGEMENT SYSTEM",
            font=("times new roman", 20, "bold"),
            bg="black", fg="gold", bd=4, relief=RIDGE
        )
        lbl_title.place(x=0, y=140, width=1550, height=50)

        # ===================== main frame ======================
        self.main_frame = Frame(self.root, bd=4, relief=RIDGE)
        self.main_frame.place(x=0, y=190, width=1550, height=620)

        # ===================== MENU ======================
        lbl_menu = Label(
            self.main_frame, text="MENU",
            font=("times new roman", 20, "bold"),
            bg="black", fg="gold", bd=4, relief=RIDGE
        )
        lbl_menu.place(x=0, y=0, width=230)

        # ===================== Button Frame ======================
        self.btn_frame = Frame(self.main_frame, bd=4, relief=RIDGE)
        self.btn_frame.place(x=0, y=35, width=228, height=190)

        # CUSTOMER BUTTON
        cust_btn = Button(
            self.btn_frame, text="CUSTOMER", width=22,
            font=("times new roman", 14, "bold"), bg="black", fg="gold",
            bd=0, cursor="hand1", command=self.open_customer_window
        )
        cust_btn.grid(row=0, column=0, pady=1)

        # ROOM BUTTON
        room_btn = Button(
            self.btn_frame, text="ROOM", width=22,
            font=("times new roman", 14, "bold"), bg="black", fg="gold",
            bd=0, cursor="hand1", command=self.open_room_window
        )
        room_btn.grid(row=1, column=0, pady=1)

        # DETAILS BUTTON
        details_btn = Button(
            self.btn_frame, text="DETAILS", width=22,
            font=("times new roman", 14, "bold"), bg="black", fg="gold",
            bd=0, cursor="hand1", command=self.open_details_window
        )
        details_btn.grid(row=2, column=0, pady=1)

   

        # LOGOUT BUTTON  
        logout_btn = Button(
            self.btn_frame, text="LOGOUT", width=22,
            font=("times new roman", 14, "bold"), bg="black", fg="gold",
            bd=0, cursor="hand1", command=self.logout
        )
        logout_btn.grid(row=3, column=0, pady=1)

        # ===================== right side big image ======================
        img3 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel8.jpg")
        img3 = img3.resize((1310, 590), Image.LANCZOS)
        self.photoimg3 = ImageTk.PhotoImage(img3)

        lblimg3 = Label(self.main_frame, image=self.photoimg3, bd=4, relief=RIDGE)
        lblimg3.place(x=225, y=0, width=1310, height=590)

        # ===================== down images ======================
        img4 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel6.jpg")
        img4 = img4.resize((230, 250), Image.LANCZOS)
        self.photoimg4 = ImageTk.PhotoImage(img4)

        lblimg4 = Label(self.main_frame, image=self.photoimg4, bd=4, relief=RIDGE)
        lblimg4.place(x=0, y=187, width=230, height=210)

        img5 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel7.jpg")
        img5 = img5.resize((230, 250), Image.LANCZOS)
        self.photoimg5 = ImageTk.PhotoImage(img5)

        lblimg5 = Label(self.main_frame, image=self.photoimg5, bd=4, relief=RIDGE)
        lblimg5.place(x=0, y=390, width=230, height=210)

        # ===================== OPEN CUSTOMER PAGE ======================
    def open_customer_window(self):
        new_window = Toplevel(self.root)
        cust_win(new_window)

    # ===================== OPEN ROOM BOOKING PAGE ======================
    def open_room_window(self):
        new_window = Toplevel(self.root)
        Roombooking(new_window)

    # ==================== OPEN DETAILS PAGE =========================
    def open_details_window(self):
        new_window = Toplevel(self.root)
        DetailsRoom(new_window)

    # ============ LOGOUT FUNCTION ===============
    def logout(self):
        self.root.destroy()





            



if __name__ == "__main__":
    main()
