from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import random
from datetime import datetime
import mysql.connector


class Roombooking:
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Management")
        self.root.geometry("1295x550+230+220")

        # ============ VARIABLES =============
        self.var_ref = StringVar()
        x = random.randint(1000, 9999)
        self.var_ref.set(str(x))

        self.var_contact = StringVar()
        self.var_room_type = StringVar()
        self.var_checkin = StringVar()
        self.var_checkout = StringVar()
        self.var_roomavailable = StringVar()
        self.var_meal = StringVar()
        self.var_no_of_days = StringVar()
        self.var_paid_tax = StringVar()
        self.var_sub_total = StringVar()
        self.var_total_cost = StringVar()

        # ================= TITLE ==================
        lbl_title = Label(self.root, text="ROOM BOOKING DETAILS",
                          font=("arial", 18, "bold"),
                          bg="black", fg="gold", bd=4, relief=RIDGE)
        lbl_title.place(x=0, y=0, width=1295, height=50)

        # ================= LOGO IMAGE ==================
        try:
            img2 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel3.jpg")
            img2 = img2.resize((100, 40), Image.LANCZOS)
            self.photoimg2 = ImageTk.PhotoImage(img2)
            Label(self.root, image=self.photoimg2, bd=0, relief=RIDGE).place(x=5, y=2, width=100, height=40)
        except Exception:
            pass

        # ================= LEFT LABEL FRAME ==================
        self.labelframeleft = LabelFrame(self.root, bd=2, relief=RIDGE,
                                         text="Room Booking Details",
                                         font=("arial", 12, "bold"), padx=2)
        self.labelframeleft.place(x=2, y=50, width=425, height=490)

        # ================= CUSTOMER CONTACT ==================
        Label(self.labelframeleft, text="Customer Contact:",
              font=("arial", 12, "bold")).grid(row=0, column=0, padx=10, pady=5, sticky=W)

        entry_contact = ttk.Entry(self.labelframeleft, textvariable=self.var_contact,
                                  width=16, font=("arial", 13))
        entry_contact.grid(row=0, column=1, padx=10, pady=5, sticky=W)

        # ================= FETCH DATA BUTTON ==================
        Button(self.labelframeleft, text="Fetch Data",
               command=self.Fetch_contact,
               font=("arial", 11, "bold"), bg="black",
               fg="gold", width=10).place(x=305, y=2)

        # ================= ROOM TYPE ==================
        Label(self.labelframeleft, text="Room Type:",
              font=("arial", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky=W)

        combo_room = ttk.Combobox(self.labelframeleft, textvariable=self.var_room_type,
                                  font=("arial", 12), width=20, state="readonly")
        combo_room["values"] = ("Single", "Double", "Luxury")
        combo_room.grid(row=1, column=1, padx=10, pady=5)
        combo_room.current(0)

        # CHECK-IN
        Label(self.labelframeleft, text="Check-In Date:",
              font=("arial", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky=W)

        ttk.Entry(self.labelframeleft, textvariable=self.var_checkin,
                  width=22, font=("arial", 13)).grid(row=2, column=1, padx=10, pady=5)

        # CHECK-OUT
        Label(self.labelframeleft, text="Check-Out Date:",
              font=("arial", 12, "bold")).grid(row=3, column=0, padx=10, pady=5, sticky=W)

        ttk.Entry(self.labelframeleft, textvariable=self.var_checkout,
                  width=22, font=("arial", 13)).grid(row=3, column=1, padx=10, pady=5)

        # AVAILABLE ROOM
        Label(self.labelframeleft, text="Available Room:",
              font=("arial", 12, "bold")).grid(row=4, column=0, padx=10, pady=5, sticky=W)

        # -------- FIXED SQL ROOM NUMBER COMBO --------
        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            cursor = conn.cursor()
            cursor.execute("SELECT RoomNo FROM details")
            rows = cursor.fetchall()
            conn.close()

            room_list = [str(r[0]) for r in rows]

        except:
            room_list = []

        combo_roomNo = ttk.Combobox(self.labelframeleft, textvariable=self.var_roomavailable,
                                    font=("arial", 12), width=20, state="readonly")
        combo_roomNo["values"] = room_list
        combo_roomNo.grid(row=4, column=1, padx=10, pady=5)

        # MEAL
        Label(self.labelframeleft, text="Meal:",
              font=("arial", 12, "bold")).grid(row=5, column=0, padx=10, pady=5, sticky=W)

        combo_meal = ttk.Combobox(self.labelframeleft, textvariable=self.var_meal,
                                  font=("arial", 12), width=20, state="readonly")
        combo_meal["values"] = ("Breakfast", "Lunch", "Dinner", "No Meal")
        combo_meal.grid(row=5, column=1, padx=10, pady=5, sticky=W)
        combo_meal.current(0)

        # NO OF DAYS
        Label(self.labelframeleft, text="No Of Days:",
              font=("arial", 12, "bold")).grid(row=6, column=0, padx=10, pady=5, sticky=W)

        ttk.Entry(self.labelframeleft, textvariable=self.var_no_of_days,
                  font=("arial", 13, "bold"), width=22).grid(row=6, column=1, padx=10, pady=5)

        # PAID TAX
        Label(self.labelframeleft, text="Paid Tax:",
              font=("arial", 12, "bold")).grid(row=7, column=0, padx=10, pady=5, sticky=W)

        ttk.Entry(self.labelframeleft, textvariable=self.var_paid_tax,
                  font=("arial", 13, "bold"), width=22, state="readonly").grid(row=7, column=1, padx=10, pady=5)

        # SUB TOTAL
        Label(self.labelframeleft, text="Sub Total:",
              font=("arial", 12, "bold")).grid(row=8, column=0, padx=10, pady=5, sticky=W)

        ttk.Entry(self.labelframeleft, textvariable=self.var_sub_total,
                  font=("arial", 13, "bold"), width=22, state="readonly").grid(row=8, column=1, padx=10, pady=5)

        # TOTAL COST
        Label(self.labelframeleft, text="Total Cost:",
              font=("arial", 12, "bold")).grid(row=9, column=0, padx=10, pady=5, sticky=W)

        ttk.Entry(self.labelframeleft, textvariable=self.var_total_cost,
                  font=("arial", 13, "bold"), width=22, state="readonly").grid(row=9, column=1, padx=10, pady=5)

        # BILL BUTTON
        Button(self.labelframeleft, text="Bill", command=self.total,
               font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=10, column=0, padx=10, pady=5, sticky=W)

        # BUTTON FRAME
        btn_frame = Frame(self.labelframeleft, bd=2, relief=RIDGE)
        btn_frame.place(x=0, y=400, width=520, height=40)

        Button(btn_frame, text="Add", command=self.add_data, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=0)

        Button(btn_frame, text="Update", command=self.update, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=1)

        Button(btn_frame, text="Delete", command=self.mDelete, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=2)

        Button(btn_frame, text="Reset", command=self.reset, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=3)

        # ================= TABLE FRAME =================
        Table_Frame = LabelFrame(self.root, bd=2, relief=RIDGE,
                                 text="View Details And Search System",
                                 font=("arial", 12, "bold"))
        Table_Frame.place(x=435, y=277, width=860, height=490)

        Label(Table_Frame, text="Search By:", font=("arial", 12, "bold"),
              bg="gold", fg="white").grid(row=0, column=0, padx=2, sticky=W)

        self.search_var = StringVar()
        combo_Search = ttk.Combobox(Table_Frame, textvariable=self.search_var,
                                    font=("arial", 12, "bold"), width=24,
                                    state="readonly")
        combo_Search["values"] = ("Contact", "Room")
        combo_Search.grid(row=0, column=1)
        combo_Search.current(0)

        self.txt_search = StringVar()
        ttk.Entry(Table_Frame, textvariable=self.txt_search,
                  font=("arial", 11, "bold"), width=24).grid(row=0, column=2, padx=2)

        Button(Table_Frame, text="Search", command=self.search, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=3, padx=2)

        Button(Table_Frame, text="Show All", command=self.fetch_data, font=("arial", 11, "bold"),
               bg="black", fg="gold", width=10).grid(row=0, column=4, padx=2)

        # RIGHT IMAGE
        try:
            img3 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel6.jpg")
            img3 = img3.resize((400, 230), Image.LANCZOS)
            self.photoimg3 = ImageTk.PhotoImage(img3)
            Label(self.root, image=self.photoimg3, bd=0, relief=RIDGE).place(x=890, y=55, width=400, height=230)
        except Exception:
            pass

        # TABLE AREA
        details_table = Frame(Table_Frame, bd=2, relief=RIDGE)
        details_table.place(x=0, y=50, width=860, height=400)

        scroll_x = ttk.Scrollbar(details_table, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(details_table, orient=VERTICAL)

        self.room_Table = ttk.Treeview(
            details_table,
            columns=("Contact", "Check_in", "Check_out", "Roomtype", "Roomavailable", "Meal", "NoOfdays"),
            xscrollcommand=scroll_x.set,
            yscrollcommand=scroll_y.set,
            show="headings"
        )

        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.room_Table.xview)
        scroll_y.config(command=self.room_Table.yview)

        for col in ("Contact", "Check_in", "Check_out", "Roomtype", "Roomavailable", "Meal", "NoOfdays"):
            self.room_Table.heading(col, text=col)
            self.room_Table.column(col, width=120)

        self.room_Table.pack(fill=BOTH, expand=1)

        self.room_Table.bind("<ButtonRelease-1>", self.get_cursor)
        self.fetch_data()

    # ====================================================================

    def add_data(self):
        if self.var_contact.get().strip() == "" or self.var_checkin.get().strip() == "":
            messagebox.showerror("Error", "Contact and Check-in date are required", parent=self.root)
            return
        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            mycursor = conn.cursor()
            insert_query = """INSERT INTO room
                (Contact, Check_in, Check_out, Roomtype, Roomavailable, Meal, NoOfdays)
                VALUES (%s, %s, %s, %s, %s, %s, %s)"""

            values = (self.var_contact.get(),
                      self.var_checkin.get(),
                      self.var_checkout.get(),
                      self.var_room_type.get(),
                      self.var_roomavailable.get(),
                      self.var_meal.get(),
                      self.var_no_of_days.get())

            mycursor.execute(insert_query, values)
            conn.commit()
            conn.close()
            self.fetch_data()
            messagebox.showinfo("Success", "Room booked", parent=self.root)

        except Exception as es:
            messagebox.showwarning("Warning", f"Something went wrong: {str(es)}", parent=self.root)

    # FETCH ALL DATA
    def fetch_data(self):
        try:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111",
                database="hotel"
            )
            my_cursor = conn.cursor()
            my_cursor.execute("SELECT Contact, Check_in, Check_out, Roomtype, Roomavailable, Meal, NoOfdays FROM room")
            rows = my_cursor.fetchall()
            conn.close()

            self.room_Table.delete(*self.room_Table.get_children())
            for i in rows:
                self.room_Table.insert("", END, values=i)
        except Exception as es:
            messagebox.showerror("Error", f"Fetch failed: {str(es)}", parent=self.root)

    # CURSOR FUNCTION
    def get_cursor(self, event=""):
        cursor_row = self.room_Table.focus()
        content = self.room_Table.item(cursor_row)
        row = content.get("values", [])

        if row:
            self.var_contact.set(row[0])
            self.var_checkin.set(row[1])
            self.var_checkout.set(row[2])
            self.var_room_type.set(row[3])
            self.var_roomavailable.set(row[4])
            self.var_meal.set(row[5])
            self.var_no_of_days.set(row[6])

    # UPDATE FUNCTION
    def update(self):
        if self.var_contact.get().strip() == "":
            messagebox.showerror("Error", "Please enter mobile number", parent=self.root)
            return
        try:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111",
                database="hotel"
            )
            my_cursor = conn.cursor()
            update_query = """
                UPDATE room
                SET Check_in=%s, Check_out=%s, Roomtype=%s, Roomavailable=%s, Meal=%s, NoOfdays=%s
                WHERE Contact=%s
            """

            values = (self.var_checkin.get(),
                      self.var_checkout.get(),
                      self.var_room_type.get(),
                      self.var_roomavailable.get(),
                      self.var_meal.get(),
                      self.var_no_of_days.get(),
                      self.var_contact.get())

            my_cursor.execute(update_query, values)
            conn.commit()
            conn.close()
            self.fetch_data()
            messagebox.showinfo("Update", "Room details updated successfully", parent=self.root)
        except Exception as es:
            messagebox.showerror("Error", f"Update failed: {str(es)}", parent=self.root)

    # DELETE FUNCTION
    def mDelete(self):
        ask = messagebox.askyesno("Hotel Management System", "Do you want to delete this booking?", parent=self.root)
        if ask:
            try:
                conn = mysql.connector.connect(
                    host="localhost", username="root", password="Poojagarg@111",
                    database="hotel"
                )
                my_cursor = conn.cursor()
                query = "DELETE FROM room WHERE Contact=%s"
                value = (self.var_contact.get(),)
                my_cursor.execute(query, value)
                conn.commit()
                conn.close()
                self.fetch_data()
            except Exception as es:
                messagebox.showerror("Error", f"Delete failed: {str(es)}", parent=self.root)

    # RESET FUNCTION
    def reset(self):
        self.var_contact.set("")
        self.var_room_type.set("Single")
        self.var_checkin.set("")
        self.var_checkout.set("")
        self.var_roomavailable.set("")
        self.var_meal.set("Breakfast")
        self.var_no_of_days.set("")
        self.var_paid_tax.set("")
        self.var_sub_total.set("")
        self.var_total_cost.set("")

    # FETCH CONTACT DETAILS
    def Fetch_contact(self):
        if self.var_contact.get().strip() == "":
            messagebox.showerror("Error", "Please enter contact number", parent=self.root)
            return
        try:
            conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Poojagarg@111",
                database="hotel"
            )
            cursor = conn.cursor()
            query = "SELECT Name, Gender, Email, Nationality, Address FROM customer WHERE Mobile=%s"
            cursor.execute(query, (self.var_contact.get(),))
            row = cursor.fetchone()
            conn.close()

            if row is None:
                messagebox.showerror("Error", "This number not found", parent=self.root)
                return

            showDataframe = Frame(self.root, bd=4, relief=RIDGE, padx=2)
            showDataframe.place(x=455, y=55, width=300, height=180)

            Label(showDataframe, text="Name:", font=("arial", 12, "bold")).place(x=0, y=0)
            Label(showDataframe, text=row[0], font=("arial", 12, "bold")).place(x=90, y=0)

            Label(showDataframe, text="Gender:", font=("arial", 12, "bold")).place(x=0, y=30)
            Label(showDataframe, text=row[1], font=("arial", 12, "bold")).place(x=90, y=30)

            Label(showDataframe, text="Email:", font=("arial", 12, "bold")).place(x=0, y=60)
            Label(showDataframe, text=row[2], font=("arial", 12, "bold")).place(x=90, y=60)

            Label(showDataframe, text="Nationality:", font=("arial", 12, "bold")).place(x=0, y=90)
            Label(showDataframe, text=row[3], font=("arial", 12, "bold")).place(x=90, y=90)

            Label(showDataframe, text="Address:", font=("arial", 12, "bold")).place(x=0, y=120)
            Label(showDataframe, text=row[4], font=("arial", 12, "bold")).place(x=90, y=120)

        except Exception as es:
            messagebox.showerror("Error", f"Something went wrong: {str(es)}", parent=self.root)

    # SEARCH FUNCTION
    def search(self):
        s_text = self.txt_search.get().strip()
        if s_text == "":
            messagebox.showerror("Error", "Please enter search text", parent=self.root)
            return

        col = "Contact" if self.search_var.get() == "Contact" else "Roomavailable"

        try:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111", database="hotel")
            cursor = conn.cursor()
            query = f"SELECT Contact, Check_in, Check_out, Roomtype, Roomavailable, Meal, NoOfdays FROM room WHERE {col} LIKE %s"
            cursor.execute(query, (f"%{s_text}%",))
            rows = cursor.fetchall()
            conn.close()

            self.room_Table.delete(*self.room_Table.get_children())
            for r in rows:
                self.room_Table.insert("", END, values=r)

        except Exception as es:
            messagebox.showerror("Error", f"Search failed: {str(es)}", parent=self.root)

    # BILL FUNCTION
    def total(self):
        inDate = self.var_checkin.get().strip()
        outDate = self.var_checkout.get().strip()

        if inDate == "" or outDate == "":
            messagebox.showerror("Error", "Please enter both check-in and check-out dates (DD/MM/YYYY)", parent=self.root)
            return

        try:
            in_dt = datetime.strptime(inDate, "%d/%m/%Y")
            out_dt = datetime.strptime(outDate, "%d/%m/%Y")
            days = abs((out_dt - in_dt).days)
            if days == 0:
                days = 1
            self.var_no_of_days.set(str(days))
        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Use DD/MM/YYYY", parent=self.root)
            return

        # SIMPLE PRICE LOGIC
        roomtype = self.var_room_type.get()
        meal = self.var_meal.get()

        base = 1000 if roomtype == "Single" else 1800 if roomtype == "Double" else 3000
        meal_price = 150 if meal == "Breakfast" else 250 if meal == "Lunch" else 300 if meal == "Dinner" else 0

        subtotal = (base + meal_price) * int(self.var_no_of_days.get())
        tax = subtotal * 0.10
        total = subtotal + tax

        self.var_sub_total.set(f"Rs.{subtotal:.2f}")
        self.var_paid_tax.set(f"Rs.{tax:.2f}")
        self.var_total_cost.set(f"Rs.{total:.2f}")


# ================= MAIN LOOP ==================
if __name__ == "__main__":
    root = Tk()
    app = Roombooking(root)
    root.mainloop()
