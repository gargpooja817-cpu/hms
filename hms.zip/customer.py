from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import random
import mysql.connector


class cust_win:
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Management")
        self.root.geometry("1295x550+230+220")

        # ============ VARIABLES =============
        self.var_ref = StringVar()
        x = random.randint(1000, 9999)
        self.var_ref.set(str(x))

        self.var_cust_name = StringVar()
        self.var_mother = StringVar()
        self.var_gender = StringVar()
        self.var_post = StringVar()
        self.var_mobile = StringVar()
        self.var_email = StringVar()
        self.var_nationality = StringVar()
        self.var_adderss = StringVar()
        self.var_id_proof = StringVar()
        self.var_id_number = StringVar()

        # ============ TITLE =============
        lbl_title = Label(self.root, text="ADD CUSTOMER DETAILS",
                          font=("arial", 18, "bold"), bg="black",
                          fg="gold", bd=4, relief=RIDGE)
        lbl_title.place(x=0, y=0, width=1295, height=50)

        # ============ LOGO ============
        img2 = Image.open(r"C:\Users\pooja garg\Desktop\management system\images\hotel3.jpg")
        img2 = img2.resize((100, 40), Image.LANCZOS)
        self.photoimg2 = ImageTk.PhotoImage(img2)

        lbling = Label(self.root, image=self.photoimg2, bd=0, relief=RIDGE)
        lbling.place(x=5, y=2, width=100, height=40)

        # ============ LEFT LABEL FRAME ============
        self.labelframeleft = LabelFrame(self.root, bd=2, relief=RIDGE,
                                         text="Customer Details",
                                         font=("arial", 12, "bold"), padx=2)
        self.labelframeleft.place(x=2, y=50, width=425, height=490)

        # Customer Ref
        lbl_cust_ref = Label(self.labelframeleft, text="Customer Ref",
                             font=("arial", 12, "bold"), padx=2, pady=6)
        lbl_cust_ref.grid(row=0, column=0, sticky=W)

        entry_ref = ttk.Entry(self.labelframeleft, textvariable=self.var_ref,
                              width=29, state="readonly", font=("arial", 13, "bold"))
        entry_ref.grid(row=0, column=1)

        # Customer Name
        cname = Label(self.labelframeleft, text="Customer Name",
                      font=("arial", 12, "bold"), padx=2, pady=6)
        cname.grid(row=1, column=0, sticky=W)

        txtcname = ttk.Entry(self.labelframeleft, textvariable=self.var_cust_name,
                             font=("arial", 13, "bold"), width=29)
        txtcname.grid(row=1, column=1)

        # Mother Name
        lblmname = Label(self.labelframeleft, text="Mother Name",
                         font=("arial", 12, "bold"), padx=2, pady=6)
        lblmname.grid(row=2, column=0, sticky=W)

        txtmname = ttk.Entry(self.labelframeleft, textvariable=self.var_mother,
                             font=("arial", 13, "bold"), width=29)
        txtmname.grid(row=2, column=1)

        # Gender
        label_gender = Label(self.labelframeleft, font=("arial", 12, "bold"),
                             text="Gender:", padx=2, pady=6)
        label_gender.grid(row=3, column=0, sticky=W)

        combo_gender = ttk.Combobox(self.labelframeleft, textvariable=self.var_gender,
                                    font=("arial", 12, "bold"), width=27, state="readonly")
        combo_gender['values'] = ("Male", "Female", "Other")
        combo_gender.current(0)
        combo_gender.grid(row=3, column=1)

        # PostCode
        lblPostCode = Label(self.labelframeleft, font=("arial", 12, "bold"),
                            text="PostCode:", padx=2, pady=6)
        lblPostCode.grid(row=4, column=0, sticky=W)

        txtPostCode = ttk.Entry(self.labelframeleft, textvariable=self.var_post,
                                font=("arial", 13, "bold"), width=29)
        txtPostCode.grid(row=4, column=1)

        # Mobile
        lblMobile = Label(self.labelframeleft, font=("arial", 12, "bold"),
                          text="Mobile:", padx=2, pady=6)
        lblMobile.grid(row=5, column=0, sticky=W)

        txtMobile = ttk.Entry(self.labelframeleft, textvariable=self.var_mobile,
                              font=("arial", 13, "bold"), width=29)
        txtMobile.grid(row=5, column=1)

        # Email
        lblEmail = Label(self.labelframeleft, font=("arial", 12, "bold"),
                         text="Email:", padx=2, pady=6)
        lblEmail.grid(row=6, column=0, sticky=W)

        txtEmail = ttk.Entry(self.labelframeleft, textvariable=self.var_email,
                             font=("arial", 13, "bold"), width=29)
        txtEmail.grid(row=6, column=1)

        # Nationality
        lblNationality = Label(self.labelframeleft, font=("arial", 12, "bold"),
                               text="Nationality:", padx=2, pady=6)
        lblNationality.grid(row=7, column=0, sticky=W)

        combo_nationality = ttk.Combobox(self.labelframeleft,
                                         textvariable=self.var_nationality,
                                         font=("arial", 12, "bold"), width=27, state="readonly")
        combo_nationality['values'] = ("Indian", "American", "British")
        combo_nationality.current(0)
        combo_nationality.grid(row=7, column=1)

        # ID Proof
        lblIdProof = Label(self.labelframeleft, font=("arial", 12, "bold"),
                           text="Id Proof Type:", padx=2, pady=6)
        lblIdProof.grid(row=8, column=0, sticky=W)

        combo_id = ttk.Combobox(self.labelframeleft, textvariable=self.var_id_proof,
                                font=("arial", 12, "bold"), width=27, state="readonly")
        combo_id['values'] = ("Aadhar", "Driving Licence", "Passport")
        combo_id.current(0)
        combo_id.grid(row=8, column=1)

        # ID Number
        lblIdNumber = Label(self.labelframeleft, font=("arial", 12, "bold"),
                            text="Id Number:", padx=2, pady=6)
        lblIdNumber.grid(row=9, column=0, sticky=W)

        txtIdNumber = ttk.Entry(self.labelframeleft, textvariable=self.var_id_number,
                                font=("arial", 13, "bold"), width=29)
        txtIdNumber.grid(row=9, column=1)

        # Address
        lblAddress = Label(self.labelframeleft, font=("arial", 12, "bold"),
                           text="Address:", padx=2, pady=6)
        lblAddress.grid(row=10, column=0, sticky=W)

        txtAddress = ttk.Entry(self.labelframeleft, textvariable=self.var_adderss,
                               font=("arial", 13, "bold"), width=29)
        txtAddress.grid(row=10, column=1)

        # ========== BUTTON FRAME ==========
        btn_frame = Frame(self.labelframeleft, bd=2, relief=RIDGE)
        btn_frame.place(x=0, y=400, width=412, height=40)

        Button(btn_frame, text="Add", command=self.add_data,
               font=("arial", 11, "bold"), bg="black", fg="gold", width=10).grid(row=0, column=0)

        Button(btn_frame, text="Update", command=self.update,
               font=("arial", 11, "bold"), bg="black", fg="gold", width=10).grid(row=0, column=1)

        Button(btn_frame, text="Delete", command=self.mDelete,
               font=("arial", 11, "bold"), bg="black", fg="gold", width=10).grid(row=0, column=2)

        Button(btn_frame, text="Reset", command=self.reset,
               font=("arial", 11, "bold"), bg="black", fg="gold", width=10).grid(row=0, column=3)

        # ================= TABLE FRAME =================
        Table_Frame = LabelFrame(self.root, bd=2, relief=RIDGE,
                                 text="View Details And Search System",
                                 font=("arial", 12, "bold"))
        Table_Frame.place(x=435, y=50, width=860, height=490)

        lblSearchBy = Label(Table_Frame, font=("arial", 12, "bold"),
                            text="Search By:", bg="gold", fg="white")
        lblSearchBy.grid(row=0, column=0, sticky=W, padx=2)

        self.search_var = StringVar()
        combo_Search = ttk.Combobox(Table_Frame, textvariable=self.search_var,
                                    font=("arial", 12, "bold"), width=24, state="readonly")
        combo_Search['values'] = ("Mobile", "Ref")
        combo_Search.current(0)
        combo_Search.grid(row=0, column=1)

        self.txt_search = StringVar()
        txtSearch = ttk.Entry(Table_Frame, textvariable=self.txt_search,
                              font=("arial", 11, "bold"), width=24)
        txtSearch.grid(row=0, column=2, padx=2)

        Button(Table_Frame, text="Search", command=self.search,
               font=("arial", 11, "bold"), bg="black", fg="gold",
               width=10).grid(row=0, column=3, padx=2)

        Button(Table_Frame, text="Show All", command=self.fetch_data,
               font=("arial", 11, "bold"), bg="black", fg="gold",
               width=10).grid(row=0, column=4, padx=2)

        # =========== TABLE AREA ============
        details_table = Frame(Table_Frame, bd=2, relief=RIDGE)
        details_table.place(x=0, y=50, width=860, height=350)

        scroll_x = ttk.Scrollbar(details_table, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(details_table, orient=VERTICAL)

        self.Cust_Details_Table = ttk.Treeview(details_table,
                                               columns=(
                                                   "ref", "name", "mother", "gender", "post",
                                                   "mobile", "email", "nationality", "address",
                                                   "idproof", "idnumber"
                                               ),
                                               xscrollcommand=scroll_x.set,
                                               yscrollcommand=scroll_y.set)

        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.Cust_Details_Table.xview)
        scroll_y.config(command=self.Cust_Details_Table.yview)

        headings = {
            "ref": "Refer No",
            "name": "Name",
            "mother": "Mother Name",
            "gender": "Gender",
            "post": "PostCode",
            "mobile": "Mobile",
            "email": "Email",
            "nationality": "Nationality",
            "address": "Address",
            "idproof": "ID Proof",
            "idnumber": "ID Number"
        }

        for col, text in headings.items():
            self.Cust_Details_Table.heading(col, text=text)
            self.Cust_Details_Table.column(col, width=100)

        self.Cust_Details_Table.pack(fill=BOTH, expand=1)
        self.Cust_Details_Table.bind("<ButtonRelease-1>", self.get_cursor)

        self.fetch_data()

    # =============== ADD DATA =================
    def add_data(self):
        if self.var_mobile.get() == "" or self.var_cust_name.get() == "":
            messagebox.showerror("Error", "All fields are required", parent=self.root)
        else:
            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    username="root",
                    password="Poojagarg@111",
                    database="hotel"
                )
                mycursor = conn.cursor()

                mycursor.execute(
                    "INSERT INTO customer (Ref, Name, Mother, Gender, Postcode, Mobile, Email, Nationality, Address, Id_proof, Id_number) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                    (
                        self.var_ref.get(),
                        self.var_cust_name.get(),
                        self.var_mother.get(),
                        self.var_gender.get(),
                        self.var_post.get(),
                        self.var_mobile.get(),
                        self.var_email.get(),
                        self.var_nationality.get(),
                        self.var_adderss.get(),
                        self.var_id_proof.get(),
                        self.var_id_number.get()
                    )
                )

                conn.commit()
                conn.close()
                self.fetch_data()
                messagebox.showinfo("Success", "Customer has been added", parent=self.root)

            except Exception as es:
                messagebox.showwarning("Warning", f"Something went wrong: {str(es)}", parent=self.root)

    # ================= FETCH =================
    def fetch_data(self):
        conn = mysql.connector.connect(
            host="localhost", username="root", password="Poojagarg@111",
            database="hotel"
        )
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT * FROM customer")
        rows = my_cursor.fetchall()

        self.Cust_Details_Table.delete(*self.Cust_Details_Table.get_children())

        for i in rows:
            self.Cust_Details_Table.insert("", END, values=i)

        conn.close()

    # ================= GET CURSOR =================
    def get_cursor(self, event=""):
        cursor_row = self.Cust_Details_Table.focus()
        content = self.Cust_Details_Table.item(cursor_row)
        row = content["values"]

        if row:
            self.var_ref.set(row[0])
            self.var_cust_name.set(row[1])
            self.var_mother.set(row[2])
            self.var_gender.set(row[3])
            self.var_post.set(row[4])
            self.var_mobile.set(row[5])
            self.var_email.set(row[6])
            self.var_nationality.set(row[7])
            self.var_adderss.set(row[8])
            self.var_id_proof.set(row[9])
            self.var_id_number.set(row[10])

    # ================= UPDATE =================
    def update(self):
        if self.var_mobile.get() == "":
            messagebox.showerror("Error", "Please enter mobile number", parent=self.root)
        else:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111",
                database="hotel"
            )
            my_cursor = conn.cursor()

            my_cursor.execute(
                "UPDATE customer SET Name=%s, Mother=%s, Gender=%s, Postcode=%s, Mobile=%s, Email=%s, Nationality=%s, Address=%s, Id_proof=%s, Id_number=%s WHERE Ref=%s",
                (
                    self.var_cust_name.get(),
                    self.var_mother.get(),
                    self.var_gender.get(),
                    self.var_post.get(),
                    self.var_mobile.get(),
                    self.var_email.get(),
                    self.var_nationality.get(),
                    self.var_adderss.get(),
                    self.var_id_proof.get(),
                    self.var_id_number.get(),
                    self.var_ref.get()
                )
            )

            conn.commit()
            conn.close()
            self.fetch_data()
            messagebox.showinfo("Update", "Customer details updated successfully", parent=self.root)

    # ================= DELETE =================
    def mDelete(self):
        mDelete = messagebox.askyesno("Hotel Management System",
                                      "Do you want to delete this customer?",
                                      parent=self.root)
        if mDelete:
            conn = mysql.connector.connect(
                host="localhost", username="root", password="Poojagarg@111",
                database="hotel"
            )
            my_cursor = conn.cursor()
            query = "DELETE FROM customer WHERE Ref=%s"
            value = (self.var_ref.get(),)
            my_cursor.execute(query, value)
            conn.commit()
            conn.close()
            self.fetch_data()

    # ================= RESET =================
    def reset(self):
        x = random.randint(1000, 9999)
        self.var_ref.set(str(x))
        self.var_cust_name.set("")
        self.var_mother.set("")
        self.var_gender.set("Male")
        self.var_post.set("")
        self.var_mobile.set("")
        self.var_email.set("")
        self.var_nationality.set("Indian")
        self.var_adderss.set("")
        self.var_id_proof.set("Aadhar")
        self.var_id_number.set("")

    # ================= SEARCH =================
    def search(self):
        conn = mysql.connector.connect(
            host="localhost", username="root", password="Poojagarg@111",
            database="hotel"
        )
        my_cursor = conn.cursor()

        query = f"SELECT * FROM customer WHERE {self.search_var.get()} LIKE %s"
        value = ("%"+self.txt_search.get()+"%",)

        my_cursor.execute(query, value)
        rows = my_cursor.fetchall()

        self.Cust_Details_Table.delete(*self.Cust_Details_Table.get_children())
        for i in rows:
            self.Cust_Details_Table.insert("", END, values=i)

        conn.close()


# -------------- MAIN ------------------
if __name__ == "__main__":
    root = Tk()
    obj = cust_win(root)
    root.mainloop()
